#include <stdio.h>
#include <stdlib.h>

int main ()
{
FILE *fwrite, *fread; //pointer to write and read

fwrite = fopen ("audio.txt", "w");//write
fread = fopen("audio.txt", "r"); //read

int channel;
float sampling_rate, time, bitDepth, audiosize;
char answer;

    if(fwrite ==NULL)
    {
    printf ("File is not found.\n");
    exit(1); //0 to terminate 1 is sucessful
    }

    else
    {
        printf ("=========================================\n");
        printf ("=\t CALCUCLATE AUDIO DATA SIZE\t=\n");
        printf ("=========================================\n");
    }


do{
    printf ("Enter channel - [1] Mono [2] Stereo\t : ");
    scanf ("%d", &channel);

    printf ("Enter sampling rate (Hz)\t\t : ");
    scanf ("%f", &sampling_rate);

    printf ("Enter time (second)\t\t\t : ");
    scanf ("%f", &time);

    printf ("Enter audio bit depth (bits)\t\t : ");
    scanf ("%f", &bitDepth);


audiosize = channel * sampling_rate * time * (bitDepth/8); //calculation of audio size

fprintf (fwrite, "%d %.2f %.2f %.2f %.2f", channel, sampling_rate, time, bitDepth, audiosize);

fflush (stdin);
printf ("add another record (y/n)? ");
scanf ("%c", &answer);
printf ("\n");

} while (answer == 'Y' || answer == 'y'); //if yes go to do back

printf ("Channel\t  Sampling rate\t Time\t Bit Depth\t Audio Size\t\n");
printf ("------------------------------------------------------------\n");
while (fscanf(fread, "%d %f %f %f %f", &channel, &sampling_rate, &time, &bitDepth, &audiosize)==5);
printf ("%d\t  %.2f\t\t %.0f\t %.0f\t\t %.2f\t", channel, sampling_rate, time, bitDepth, audiosize);

fclose(fwrite); //must close write
fclose(fread); //must close read

return 0;
}

