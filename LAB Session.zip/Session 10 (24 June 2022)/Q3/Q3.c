#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main ()
{
FILE *input;

input = fopen ("location.txt", "r"); // to read

char university[20], location [30];
float latitude, longitude;
int found;

printf ("Enter a location: ");
gets (university);
//scanf ("%s", university);

if(input ==NULL)
    {
    printf ("File does not exist.\n");
    exit(1); //0 to terminate 1 is sucessful
    }

    else
    {
        while (fscanf(input, "%s%f%f", location, &latitude, &longitude)==3) //for put info file 3 is the variable
        if (strcmp(location, university)==0)
        {

            found =1;
            break;
        }

        if (found == 1)
        {
            printf ("\n");
            printf ("Location : %s\n", location);
            printf ("Latitude : %.4f\n", latitude);
            printf ("Longitude : %.4f\n", longitude);
        }

        else
        {
            printf ("Sorry, location could not be found.");
        }
    }
fclose(input);
return 0;
}
