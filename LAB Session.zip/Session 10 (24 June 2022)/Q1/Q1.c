#include <stdio.h>

int main ()
{

FILE *input, *output;
input = fopen ("summon_list.txt", "r"); //read
output = fopen ("summon_list.txt", "a"); //append

char name [30];
float speed, fee;

while (fscanf(input, "%s%f", name, &speed)==2) //2 sebab string and float
{
    if(speed >= 100)
        {
            fee = 300;
        }
    else
    {
        fee = 150;
    }

fprintf (output, "\n%s %.0f %.2f", name, speed, fee);
}
fclose (input);
fclose (output);
return 0;

}
