#include <stdio.h>
#define ST .06
int main ()
{
    int friends;
    float lunch_bill, total_bill, tax, individual_bill;

    printf("Enter the bill for lunch     : RM ");
    scanf("%f", &lunch_bill);

    printf("Enter total number of friends: ");
    scanf ("%i", &friends);

    tax= lunch_bill*ST;
    total_bill = tax + lunch_bill;
    individual_bill = total_bill / friends;

    printf("Lunch bill\t: RM%.2f\n", lunch_bill);
    printf("Service Tax\t: RM%.2f\n", tax);
    printf("Total bill\t: RM%.2f\n", total_bill);
    printf("Individual bill\t: RM%.2f\n", individual_bill);

    return (0);
}
