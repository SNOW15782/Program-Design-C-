#include <stdio.h>
#define pi 3.142

int main ()
{

float radius, time, circular_velocity;

printf("Enter radius (cm)   :");
scanf ("%f", &radius);

printf("Enter time (s)      :");
scanf ("%f", &time);

circular_velocity = (2 *pi*radius) / time;

printf("Radius  : %.2f cm\n", radius);
printf("Time    : %.2f seconds\n", time);
printf("Circular Velocity   : %.2f cm/s \n", circular_velocity);

return (0);

}
