#include <stdio.h>
#define POUND 2.20462
#define INCH 39.3701

int main ()
{
   int age;
   float height, weight, BMR;

        printf("Enter Height (m): ");
        scanf ("%f", &height);

        printf("Enter Weight (kg): ");
        scanf ("%f", &weight);

        printf("Enter age: ");
        scanf ("%d", &age);

        printf("Height :%.2f inches\n ", height * INCH);
        printf("Weight :%.2f pounds\n ", weight * POUND);

//BMR = 66 + (6.23 x weight in pounds) + (12.7 x height in inches) �(6.8 x age)
        BMR = 66 + (6.23 * POUND) + (12.7 * INCH) - (6.8 * age);
        printf("Basal Metabolic Rate (BMR) :%.2f\n ",BMR);

    return (0);
}
