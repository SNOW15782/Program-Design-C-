#include <stdio.h>
#define A4_white_price .05
#define A4_green_price .10
#define A4_pink_price .15

int main ()
{
  float price, total, A4_white_quantity, A4_green_quantity, A4_pink_quantity;


        printf("Quantity of white A4 paper\t: ");
        scanf ("%f", &A4_white_quantity);

        printf("Quantity of Green A4 paper\t: ");
        scanf ("%f", &A4_green_quantity);

        printf("Quantity of Pink A4 paper\t: ");
        scanf ("%f", &A4_pink_quantity);

        printf("Quantity of white A4 paper\t: RM%.2f (20 x0.05)\n", A4_white_quantity * A4_white_price);
        printf("Quantity of Green A4 paper\t: RM%.2f (25 x0.10)\n", A4_green_quantity * A4_green_price);
        printf("Quantity of Pink A4 paper\t: RM%.2f (30 x0.15)\n", A4_pink_quantity * A4_pink_price);


        printf("Total\t\t\t\t: RM%.2f ", total = (A4_white_quantity * A4_white_price) + (A4_green_quantity * A4_green_price) + (A4_pink_quantity * A4_pink_price));


return (0);
}
