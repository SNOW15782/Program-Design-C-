//MUHAMAD ARIF BIN SALLEHUDDIN
//1211206128
//LAB 8 Q3

#include <stdio.h>
#define numStudent 3

struct Marks
{
    char name [30];
    float midterm;
    float assignment;
    float lab;
    float quizzes;
    float coursework;
    float final_exam;
    float total_mark;
    char grade;
};

struct Marks studentMark [numStudent];

void get_marks ();
void compute_marks ();
void display_marks ();
void compute_grade ();


int main ()
{
get_marks ();
compute_marks ();
compute_grade ();
display_marks ();


return 0;
}

void get_marks ()
{
    int i;
    for (i=0; i<numStudent; i++)
    {
    printf ("STUDENT %d", i+1);
    printf ("\n-----------\n");

    printf ("Student Name \t: ");
    gets(studentMark[i].name);

    printf ("Midterm (15) \t: ");
    scanf ("%f", &studentMark[i].midterm);

    printf ("Assignment (15)\t: ");
    scanf ("%f", &studentMark[i].assignment);

    printf ("Quizzes (10) \t: ");
    scanf ("%f", &studentMark[i].quizzes);

    printf ("Lab (10) \t: ");
    scanf ("%f", &studentMark[i].lab);

    printf ("Final Exam (50) : ");
    scanf ("%f", &studentMark[i].final_exam);

    printf("\n");

    fflush(stdin);
    }
}

void compute_marks ()
{
    int i;
    for (i=0; i<numStudent; i++)
    {
    studentMark[i].coursework = studentMark[i].midterm + studentMark[i].assignment + studentMark[i].quizzes + studentMark[i].lab;

    studentMark [i].total_mark = studentMark[i].coursework + studentMark[i].final_exam;
    }

}

void compute_grade ()
{
    int i;
    for (i=0; i<numStudent; i++)
    {
            if (studentMark [i].total_mark >=80 && studentMark [i].total_mark <=100)
            studentMark [i].grade ='A';

            else if (studentMark [i].total_mark >=70 && studentMark [i].total_mark <80)
            studentMark [i].grade ='B';

            else if (studentMark [i].total_mark >=50 && studentMark [i].total_mark <70)
            studentMark [i].grade ='C';

            else studentMark [i].grade ='F';
    }
}
void display_marks ()
{
    int i;
    float fail =0;
    float fails= 0.0;

    printf ("\n---------------------------------------\n");
    for (i=0; i<numStudent; i++)
    {

        printf ("\nStudent %d name \t: %s",i+1 ,studentMark[i].name);
        printf ("\nMidterm (15) \t: %.2f" , studentMark[i].total_mark);
        printf ("\nAssignment (15) : %c", studentMark[i].grade);

        printf ("\n");

            if (studentMark [i].grade =='F')
            {
            fail = 1;
            fails =(fails+fail)/numStudent*100;
            }

    }
    printf ("\nThe failure rate is %.2f %%", fails);
}
