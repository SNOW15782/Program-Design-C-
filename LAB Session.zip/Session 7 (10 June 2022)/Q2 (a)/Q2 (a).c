#include <stdio.h>

void f(int *p, int m) //first value in main stored in the first parameter
{
    m = m +25; // m = 10+25 = 35
    *p = *p + ++m; //*p = 5+ 36 = 41 (i is now 41)
    return;
}

void main () // look at the main 1st
{
 int i =5, j=10;
 f (&i, j); //address of i and value of j
 printf ("%d", i+j); //41+10
}
//answer 51
