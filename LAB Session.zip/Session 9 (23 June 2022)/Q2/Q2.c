#include <stdio.h>
#include <math.h>

int main ()
{
    FILE *fread, *fwrite;
    float a,b,c;

    fread = fopen ("input", "r");
    fwrite = fopen ("output", "w");

   if(fread ==NULL)
    {
    printf ("File does not exist.\n");
    }

    else
    {
        while(!feof(fread))
        {
            fscanf(fread, "%f %f", &a, &b);
            c = sqrt(pow(a,2) + pow(b,2));
            fprintf(fwrite, "%.2f %.2f %.2f\n", a, b, c);
        }
	}
	fclose(fread);
	fclose(fwrite);
}
