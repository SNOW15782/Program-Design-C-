#include <stdio.h>
#define SIZE 4
struct Recycle
{
    char name[90];
    float weight;
    float income;
};

float Get_price(float);

int main ()
{
    struct Recycle person[SIZE];
    int x;
    float price;

    FILE *fwrite;
    fwrite = fopen("recycle.txt", "w");

        for(x=0;x<SIZE;x++)
        {
        printf ("Enter name\t\t: ");
        gets (person[x].name);

        printf ("Enter material weight\t: ");
        scanf("%f", &person[x].weight);

        fflush(stdin);

        printf("\n");

        price = Get_price(person[x].weight); //call function
        person[x].income = price * person[x].weight;


        fprintf(fwrite,"%s           \t %.2fKG    \t RM%.2f  \n",person[x].name, person[x].weight,person [x].income);
        }
 fclose(fwrite);
 return 0;
}
float Get_price(float weight)
{
float price;

    if(weight <50)
    {
        price = 0.20;
    }

    else if (weight<100)
    {
        price = 0.40;
    }
    else
    {
        price =0.60;
    }

return price;
}
