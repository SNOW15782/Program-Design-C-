#include <stdio.h>

float kilo [4];

void get_input();
void convert_gram();
void convert_pound();

int main()
{
get_input();
convert_gram ();
convert_pound();
return 0;
}


void get_input()
{
int count;
    printf ("Enter the values in kilogram:\n");
    for (count=0; count<4; count++) //loop to 4 times
    {
    scanf ( "%f", &kilo[count]);
    }
}

void convert_gram()
{
    int count;
    float kg;

    printf ("Convert kilo to gram:- \n");
    for (count=0; count<4; count++) //loop to 4 times
    {
    kg = kilo[count] * 1000; //convert kg to gram
    printf ("%.2f kg is equal to %.2f grams\n", kilo[count], kg);
    }
}

void convert_pound()
{
    int count;
    float pound;

    printf ("\nConvert kilo to pound:- \n");
    for (count=0; count<4; count++) //loop to 4 times
    {
    pound = kilo[count] * 2.205 ; //convert kg to pound
    printf ("%.2f kg is equal to %.2f pounds\n", kilo[count], pound);
    }

}
