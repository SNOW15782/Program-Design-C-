//Name: Muhamad Arif Bin Sallehuddin
//ID: 1211206128
//Lab 6 , Q4

#include <stdio.h>
int main()
{
    float array [4][5] = {{2.30, 4.00, 5.00},{3.00, 2.10, 1.00, 4.00},{1.00, 2.00, 3.00, 4.00, 5.00},{4.00, 2.50}};
    float total;
    float totalrow = 0; //total row is equal to 0
    int count = 0; //divide is equal
    int x;
    int y;

    printf ("Average Rating For Each Product\n");
    printf ("-------------------------------\n");


    for (x=0; x <4; x++) //loop 4 times
    {
     for (y=0; y <5; y++) //loop 5 times
        {
         total = array [x][y]; //operator tell that [x] [y] index is total

         totalrow = totalrow + total; //totalrow is [x][y] index

         if (array [x][y] > 0) //any index that is 0 not counted
            count ++;
        }
    totalrow = totalrow/count;

    printf ("\nProduct %d : %.2f\n", x+1, totalrow); //product start at 1 so must +1

    totalrow=0;
    count = 0;
    }
    return 0;
    }
